import React from 'react';

/**
 * The De Royal mark: four ethernet wires fanning out from one corner.
 * Outer to inner: orange, blue, green, brown, as in the logo.
 */
const WIRES = [
  { r: 34, color: '#F97316' },
  { r: 26, color: '#3B82F6' },
  { r: 18, color: '#22C55E' },
  { r: 10, color: '#B45309' },
];

interface WireMarkProps {
  size?: number;
  className?: string;
  title?: string;
}

export const WireMark: React.FC<WireMarkProps> = ({ size = 32, className = '', title }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    className={className}
    role={title ? 'img' : undefined}
    aria-label={title}
    aria-hidden={title ? undefined : true}
  >
    <rect width="64" height="64" rx="15" fill="#070E24" />
    {WIRES.map(({ r, color }) => (
      <path
        key={color}
        d={`M14 ${50 - r} A ${r} ${r} 0 0 1 ${14 + r} 50`}
        fill="none"
        stroke={color}
        strokeWidth="4"
        strokeLinecap="round"
      />
    ))}
  </svg>
);
