import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LogOut, Menu, Moon, Sun, X } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { WireMark } from '../brand/WireMark';
import { WireRule } from '../ui/console';
import { useTheme } from '../../contexts/ThemeContext';

export interface ShellNavItem {
  label: string;
  to: string;
  icon: LucideIcon;
  /** Match the path exactly (for a root route such as /admin). */
  end?: boolean;
}

interface ConsoleShellProps {
  /** Product line under the logo, e.g. "Admin console" or a tenant's business name. */
  context: string;
  nav: ShellNavItem[];
  user: { name?: string; role?: string };
  onLogout: () => void;
  /** Extra controls in the top bar, placed left of the theme toggle. */
  topbarActions?: React.ReactNode;
  /** Rendered above the page content (breadcrumbs, for example). */
  aboveContent?: React.ReactNode;
  children: React.ReactNode;
}

const isActive = (item: ShellNavItem, pathname: string) =>
  item.end ? pathname === item.to : pathname === item.to || pathname.startsWith(item.to + '/');

interface SidebarProps {
  context: string;
  nav: ShellNavItem[];
  user: { name?: string; role?: string };
  pathname: string;
  onNavigate: () => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ context, nav, user, pathname, onNavigate, onLogout }) => (
  <aside className="flex h-full w-60 shrink-0 flex-col border-r border-white/5 bg-navy-950 dark:bg-navy-900">
    <div className="px-5 pb-4 pt-5">
      <div className="flex items-center gap-3">
        <WireMark size={36} title="De Royal Hotspot" />
        <div className="min-w-0">
          <p className="text-[15px] font-extrabold leading-tight text-white">De Royal Hotspot</p>
          <p className="truncate text-xs font-medium text-slate-400">{context}</p>
        </div>
      </div>
      <WireRule className="mt-4 w-full" />
    </div>

    <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-2" aria-label="Primary">
      {nav.map((item) => {
        const active = isActive(item, pathname);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            aria-current={active ? 'page' : undefined}
            className={`relative flex min-h-[40px] items-center gap-3 rounded-xl px-3.5 text-sm font-semibold transition-colors ${
              active ? 'bg-wire-orange/15 text-wire-orange' : 'text-slate-300 hover:bg-white/5 hover:text-white'
            }`}
          >
            {active && <span className="absolute bottom-2 left-0 top-2 w-1 rounded-full bg-wire-orange" aria-hidden="true" />}
            <Icon size={17} className="shrink-0" aria-hidden="true" />
            <span className="truncate">{item.label}</span>
          </Link>
        );
      })}
    </nav>

    <div className="border-t border-white/5 p-4">
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-wire-blue/20 text-sm font-bold uppercase text-wire-blue">
          {user.name?.[0] ?? '?'}
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-white">{user.name || 'Signed in'}</p>
          {user.role && <p className="truncate text-xs text-slate-400">{user.role.replace(/_/g, ' ').toLowerCase()}</p>}
        </div>
      </div>
      <button
        onClick={onLogout}
        className="flex min-h-[40px] w-full items-center gap-2 rounded-xl px-3 text-sm font-semibold text-slate-300 transition-colors hover:bg-red-500/10 hover:text-red-400"
      >
        <LogOut size={15} aria-hidden="true" />
        Sign out
      </button>
    </div>
  </aside>
);

export const ConsoleShell: React.FC<ConsoleShellProps> = ({
  context,
  nav,
  user,
  onLogout,
  topbarActions,
  aboveContent,
  children,
}) => {
  const { pathname } = useLocation();
  const { theme, toggleTheme } = useTheme();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const current = nav.find((item) => isActive(item, pathname));

  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setDrawerOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [drawerOpen]);

  const closeDrawer = () => setDrawerOpen(false);
  const sidebarProps = { context, nav, user, pathname, onLogout };

  return (
    <div className="console-canvas flex h-screen overflow-hidden font-sans text-navy-900 dark:text-slate-100">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-[60] focus:rounded-lg focus:bg-wire-orange focus:px-4 focus:py-2 focus:text-sm focus:font-bold focus:text-navy-950"
      >
        Skip to content
      </a>

      <div className="hidden lg:flex">
        <Sidebar {...sidebarProps} onNavigate={() => undefined} />
      </div>

      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
          <div className="fixed inset-0 bg-navy-950/70 backdrop-blur-sm" onClick={closeDrawer} aria-hidden="true" />
          <div className="relative z-10 h-full">
            <Sidebar {...sidebarProps} onNavigate={closeDrawer} />
            <button
              onClick={closeDrawer}
              aria-label="Close menu"
              className="absolute -right-12 top-3 flex h-10 w-10 items-center justify-center rounded-xl bg-navy-950 text-white"
            >
              <X size={18} />
            </button>
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-slate-200/80 bg-white/70 px-4 backdrop-blur-md dark:border-white/10 dark:bg-navy-950/60 sm:px-6">
          <button
            onClick={() => setDrawerOpen(true)}
            aria-label="Open menu"
            className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10 lg:hidden"
          >
            <Menu size={20} />
          </button>
          <p className="truncate text-base font-bold text-navy-900 dark:text-white">{current?.label ?? context}</p>
          <div className="flex-1" />
          {topbarActions}
          <button
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
            className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-600 transition-colors hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10"
          >
            {theme === 'light' ? <Moon size={18} /> : <Sun size={18} className="text-wire-orange" />}
          </button>
        </header>

        <main id="main" className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="mx-auto w-full max-w-7xl">
            {aboveContent}
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
