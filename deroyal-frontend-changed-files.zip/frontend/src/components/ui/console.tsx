import React, { useId } from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, ChevronRight } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

/* ─────────────────────────────────────────────────────────────────────
   Console building blocks shared by the ISP, Platform and Admin dashboards.

   Colour meaning (from the four ethernet wires in the logo):
     orange → money and primary actions     green → online, healthy, paid
     blue   → information, traffic          brown → pending, needs a look
     red    → errors only (the one non-wire hue)

   Every class string is written out in full so Tailwind can see it.
   ───────────────────────────────────────────────────────────────────── */

export type Tone = 'orange' | 'green' | 'blue' | 'brown' | 'red' | 'slate';

interface ToneStyle {
  text: string;
  chip: string;
  strip: string;
  dot: string;
  stroke: string;
}

export const TONE: Record<Tone, ToneStyle> = {
  orange: {
    text: 'text-wire-orange-dark dark:text-wire-orange',
    chip: 'bg-wire-orange/15 text-wire-orange-dark dark:text-wire-orange',
    strip: 'bg-wire-orange',
    dot: 'bg-wire-orange',
    stroke: '#F97316',
  },
  green: {
    text: 'text-wire-green-dark dark:text-wire-green',
    chip: 'bg-wire-green/15 text-wire-green-dark dark:text-wire-green',
    strip: 'bg-wire-green',
    dot: 'bg-wire-green',
    stroke: '#22C55E',
  },
  blue: {
    text: 'text-wire-blue-dark dark:text-wire-blue',
    chip: 'bg-wire-blue/15 text-wire-blue-dark dark:text-wire-blue',
    strip: 'bg-wire-blue',
    dot: 'bg-wire-blue',
    stroke: '#3B82F6',
  },
  brown: {
    text: 'text-wire-brown dark:text-wire-brown-light',
    chip: 'bg-wire-brown/15 text-wire-brown dark:text-wire-brown-light',
    strip: 'bg-wire-brown',
    dot: 'bg-wire-brown',
    stroke: '#B45309',
  },
  red: {
    text: 'text-red-700 dark:text-red-400',
    chip: 'bg-red-500/10 text-red-700 dark:text-red-400',
    strip: 'bg-red-500',
    dot: 'bg-red-500',
    stroke: '#DC2626',
  },
  slate: {
    text: 'text-slate-600 dark:text-slate-300',
    chip: 'bg-slate-500/10 text-slate-600 dark:text-slate-300',
    strip: 'bg-slate-400',
    dot: 'bg-slate-400',
    stroke: '#7B89A6',
  },
};

/* ── Small helpers ─────────────────────────────────────────────────── */

export function greeting(date: Date = new Date()): string {
  const h = date.getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

export function timeAgo(iso: string | undefined | null, now: number = Date.now()): string {
  if (!iso) return '';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '';
  const s = Math.max(0, Math.round((now - then) / 1000));
  if (s < 60) return 'just now';
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} hr ago`;
  const d = Math.round(h / 24);
  return `${d} day${d === 1 ? '' : 's'} ago`;
}

/* ── Wire rule: the four-colour strand used as the brand divider ───── */

export const WireRule: React.FC<{ className?: string }> = ({ className = 'w-16' }) => (
  <div className={`wire-bar rounded-full ${className}`} aria-hidden="true" />
);

/* ── Panel ─────────────────────────────────────────────────────────── */

interface PanelProps {
  title?: string;
  subtitle?: string;
  action?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
}

export const Panel: React.FC<PanelProps> = ({ title, subtitle, action, className = '', children }) => (
  <section className={`panel p-5 sm:p-6 ${className}`}>
    {(title || action) && (
      <header className="mb-4 flex items-start justify-between gap-3">
        <div className="min-w-0">
          {title && <h2 className="text-base font-bold text-navy-900 dark:text-white">{title}</h2>}
          {subtitle && <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>}
        </div>
        {action && <div className="shrink-0 text-xs font-semibold">{action}</div>}
      </header>
    )}
    {children}
  </section>
);

/* ── Sparkline: pure SVG, real data only ───────────────────────────── */

interface SparklineProps {
  values: number[];
  tone?: Tone;
  height?: number;
  label: string;
  className?: string;
}

export const Sparkline: React.FC<SparklineProps> = ({ values, tone = 'blue', height = 56, label, className = '' }) => {
  const gradientId = useId();
  if (values.length < 2) return null;

  const W = 100;
  const H = 32;
  const pad = 2;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const step = W / (values.length - 1);
  const pts = values.map((v, i) => {
    const x = i * step;
    const y = max === min ? H / 2 : H - pad - ((v - min) / span) * (H - pad * 2);
    return [x, y] as const;
  });
  const line = pts.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(2)} ${y.toFixed(2)}`).join(' ');
  const area = `${line} L${W} ${H} L0 ${H} Z`;
  const stroke = TONE[tone].stroke;

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="none"
      className={`w-full ${className}`}
      style={{ height }}
      role="img"
      aria-label={label}
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={stroke} stopOpacity="0.28" />
          <stop offset="100%" stopColor={stroke} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${gradientId})`} />
      <path
        d={line}
        fill="none"
        stroke={stroke}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
};

/* ── KPI card: a coloured strand across the top, one number, one caption ── */

interface KpiCardProps {
  label: string;
  value: React.ReactNode;
  caption?: string;
  tone: Tone;
  icon: LucideIcon;
  to?: string;
  series?: number[];
  seriesLabel?: string;
}

export const KpiCard: React.FC<KpiCardProps> = ({ label, value, caption, tone, icon: Icon, to, series, seriesLabel }) => {
  const t = TONE[tone];
  const body = (
    <>
      <div className={`h-1 w-full ${t.strip}`} aria-hidden="true" />
      <div className="p-5">
        <div className="flex items-center gap-2.5">
          <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${t.chip}`}>
            <Icon size={16} aria-hidden="true" />
          </span>
          <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">{label}</span>
          {to && <ChevronRight size={14} className="ml-auto text-slate-400" aria-hidden="true" />}
        </div>
        <p className="mt-3 text-3xl font-extrabold tabular-nums tracking-tight text-navy-900 dark:text-white">{value}</p>
        {caption && <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{caption}</p>}
        {series && series.length > 1 && (
          <Sparkline values={series} tone={tone} label={seriesLabel ?? `${label} trend`} className="mt-3" height={44} />
        )}
      </div>
    </>
  );

  const shell = 'panel panel-hover block overflow-hidden';
  return to ? (
    <Link to={to} className={`${shell} focus-visible:outline-wire-blue`}>
      {body}
    </Link>
  ) : (
    <div className={shell}>{body}</div>
  );
};

/* ── What's next: one decision per row ─────────────────────────────── */

interface NextUpProps {
  tone: Tone;
  icon: LucideIcon;
  title: string;
  detail: string;
  flag?: string;
  to?: string;
}

export const NextUpItem: React.FC<NextUpProps> = ({ tone, icon: Icon, title, detail, flag, to }) => {
  const t = TONE[tone];
  const inner = (
    <>
      <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${t.chip}`}>
        <Icon size={17} aria-hidden="true" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-bold text-navy-900 dark:text-white">{title}</span>
          {flag && <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${t.chip}`}>{flag}</span>}
        </span>
        <span className="mt-0.5 block text-xs text-slate-500 dark:text-slate-400">{detail}</span>
      </span>
      {to && <ChevronRight size={16} className="shrink-0 text-slate-400" aria-hidden="true" />}
    </>
  );
  const row =
    'flex items-center gap-3 rounded-xl border border-slate-200/80 bg-white/70 p-3 dark:border-white/10 dark:bg-white/5';
  return to ? (
    <Link to={to} className={`${row} transition-colors hover:border-wire-blue`}>
      {inner}
    </Link>
  ) : (
    <div className={row}>{inner}</div>
  );
};

/* ── Feed row: something that already happened ─────────────────────── */

interface FeedItemProps {
  tone: Tone;
  icon: LucideIcon;
  title: string;
  detail?: string;
  time?: string;
}

export const FeedItem: React.FC<FeedItemProps> = ({ tone, icon: Icon, title, detail, time }) => {
  const t = TONE[tone];
  return (
    <li className="flex items-start gap-3 py-3 first:pt-0 last:pb-0">
      <span className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${t.chip}`}>
        <Icon size={14} aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-navy-900 dark:text-white">{title}</p>
        {detail && <p className="truncate text-xs text-slate-500 dark:text-slate-400">{detail}</p>}
      </div>
      {time && <span className="shrink-0 text-xs text-slate-500 dark:text-slate-400">{time}</span>}
    </li>
  );
};

/* ── Feedback ──────────────────────────────────────────────────────── */

export const Notice: React.FC<{ tone?: Tone; children: React.ReactNode }> = ({ tone = 'red', children }) => (
  <div role="alert" className={`flex items-start gap-2 rounded-xl px-4 py-3 text-sm font-medium ${TONE[tone].chip}`}>
    <AlertCircle size={16} className="mt-0.5 shrink-0" aria-hidden="true" />
    <span>{children}</span>
  </div>
);

export const Skeleton: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`animate-pulse rounded-lg bg-slate-200/70 dark:bg-white/10 ${className}`} aria-hidden="true" />
);

export const EmptyState: React.FC<{ icon: LucideIcon; title: string; body: string; action?: React.ReactNode }> = ({
  icon: Icon,
  title,
  body,
  action,
}) => (
  <div className="flex flex-col items-center px-4 py-8 text-center">
    <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-500/10 text-slate-500">
      <Icon size={20} aria-hidden="true" />
    </span>
    <p className="mt-3 text-sm font-bold text-navy-900 dark:text-white">{title}</p>
    <p className="mt-1 max-w-xs text-xs text-slate-500 dark:text-slate-400">{body}</p>
    {action && <div className="mt-4">{action}</div>}
  </div>
);
