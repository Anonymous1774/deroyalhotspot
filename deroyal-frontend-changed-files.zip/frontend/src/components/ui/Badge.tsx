import React from 'react';

interface BadgeProps {
  variant?: 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'simulated';
  children: React.ReactNode;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ variant = 'neutral', children, className = '' }) => {
  const styles = {
    success: 'bg-wire-green/15 text-wire-green-dark dark:text-wire-green border-wire-green/30',
    warning: 'bg-wire-brown/15 text-wire-brown dark:text-wire-brown-light border-wire-brown/30',
    danger: 'bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20',
    info: 'bg-wire-blue/10 text-wire-blue-dark dark:text-wire-blue border-wire-blue/25',
    neutral: 'bg-slate-500/10 text-slate-600 dark:text-slate-300 border-slate-500/20',
    simulated: 'bg-wire-orange/10 text-wire-orange-dark dark:text-wire-orange border-wire-orange/30'
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border ${styles[variant]} ${className}`}
    >
      {children}
    </span>
  );
};
