import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  className = '',
  hoverEffect = false
}) => {
  return (
    <div
      className={`panel p-6 ${
        hoverEffect ? 'panel-hover hover:border-wire-blue/40' : ''
      } ${className}`}
    >
      {children}
    </div>
  );
};
