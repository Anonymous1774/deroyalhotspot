import React from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard, Wifi, Settings, FileSpreadsheet, History,
  Network, Users, Server, ExternalLink,
} from 'lucide-react';
import { AdminUser } from '../types';
import { Breadcrumb } from '../components/Breadcrumb';
import { ConsoleShell, ShellNavItem } from '../components/layout/ConsoleShell';

interface AdminLayoutProps {
  children: React.ReactNode;
  onLogout: () => void;
  admin: AdminUser | null;
}

const NAV: ShellNavItem[] = [
  { label: 'Dashboard overview', path: '/admin',           icon: LayoutDashboard, end: true },
  { label: 'Routers & gateways', path: '/admin/routers',   icon: Server },
  { label: 'Internet plans',     path: '/admin/plans',     icon: Wifi },
  { label: 'Bandwidth profiles', path: '/admin/profiles',  icon: Network },
  { label: 'Vouchers',           path: '/admin/vouchers',  icon: FileSpreadsheet },
  { label: 'Active sessions',    path: '/admin/sessions',  icon: Users },
  { label: 'Audit system logs',  path: '/admin/logs',      icon: History },
  { label: 'Network settings',   path: '/admin/settings',  icon: Settings },
].map(({ path, ...rest }) => ({ ...rest, to: path }));

export const AdminLayout: React.FC<AdminLayoutProps> = ({ children, onLogout, admin }) => (
  <ConsoleShell
    context="Admin console"
    nav={NAV}
    user={{ name: admin?.fullName || admin?.email || 'Administrator', role: admin?.role || 'SUPER_ADMIN' }}
    onLogout={onLogout}
    aboveContent={<Breadcrumb />}
    topbarActions={
      <>
        <Link to="/" className="btn-ghost hidden text-xs sm:inline-flex">
          View site
          <ExternalLink size={13} aria-hidden="true" />
        </Link>
        <Link to="/connect" className="btn-secondary hidden text-xs sm:inline-flex">
          <Wifi size={14} aria-hidden="true" />
          View portal
        </Link>
      </>
    }
  >
    {children}
  </ConsoleShell>
);
