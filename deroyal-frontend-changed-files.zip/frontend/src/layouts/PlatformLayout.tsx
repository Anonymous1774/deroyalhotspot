import React from 'react';
import { LayoutDashboard, Building2, Package, FileText, Settings } from 'lucide-react';
import { usePlatformAuth } from '../contexts/platform/PlatformAuthContext';
import { ConsoleShell, ShellNavItem } from '../components/layout/ConsoleShell';

const NAV: ShellNavItem[] = [
  { label: 'Overview',     icon: LayoutDashboard, to: '/dashboard' },
  { label: 'ISP accounts', icon: Building2,       to: '/tenants' },
  { label: 'Sub plans',    icon: Package,         to: '/plans' },
  { label: 'Audit logs',   icon: FileText,        to: '/audit' },
  { label: 'Settings',     icon: Settings,        to: '/settings' },
];

export function PlatformLayout({ children }: { children: React.ReactNode }) {
  const { admin, logout } = usePlatformAuth();

  return (
    <ConsoleShell
      context="Platform admin"
      nav={NAV}
      user={{ name: admin?.fullName, role: 'Super admin' }}
      onLogout={logout}
    >
      {children}
    </ConsoleShell>
  );
}
