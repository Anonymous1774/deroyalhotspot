import React from 'react';
import {
  LayoutDashboard, Server, Package, Ticket, Activity,
  Users, Settings, CreditCard, Zap, ExternalLink,
} from 'lucide-react';
import { useIspAuth } from '../contexts/isp/IspAuthContext';
import { ConsoleShell, ShellNavItem } from '../components/layout/ConsoleShell';

const NAV: ShellNavItem[] = [
  { label: 'Dashboard',    icon: LayoutDashboard, to: '/dashboard' },
  { label: 'Routers',      icon: Server,          to: '/routers' },
  { label: 'BW profiles',  icon: Zap,             to: '/profiles' },
  { label: 'Plans',        icon: Package,         to: '/plans' },
  { label: 'Vouchers',     icon: Ticket,          to: '/vouchers' },
  { label: 'Sessions',     icon: Activity,        to: '/sessions' },
  { label: 'Staff',        icon: Users,           to: '/staff' },
  { label: 'Subscription', icon: CreditCard,      to: '/subscription' },
  { label: 'Settings',     icon: Settings,        to: '/settings' },
];

export function IspLayout({ children }: { children: React.ReactNode }) {
  const { user, tenant, logout } = useIspAuth();

  return (
    <ConsoleShell
      context={tenant?.businessName || tenant?.name || 'ISP console'}
      nav={NAV}
      user={{ name: user?.fullName, role: user?.tenantRole }}
      onLogout={logout}
      topbarActions={
        <a
          href="https://deroyalhotspot.name.ng/connect"
          target="_blank"
          rel="noreferrer"
          className="btn-ghost hidden text-xs sm:inline-flex"
        >
          View portal
          <ExternalLink size={13} aria-hidden="true" />
        </a>
      }
    >
      {children}
    </ConsoleShell>
  );
}
