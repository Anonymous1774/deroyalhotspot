import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Building2, Users, Server, Ticket, Activity, FlaskConical,
  PauseCircle, CheckCircle2, PlusCircle,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import platformApi from '../../services/platformApi';
import { usePlatformAuth } from '../../contexts/platform/PlatformAuthContext';
import {
  KpiCard, NextUpItem, Notice, Panel, Skeleton, TONE, WireRule, greeting,
} from '../../components/ui/console';
import type { Tone } from '../../components/ui/console';

interface PlatformStats {
  totalTenants: number;
  activeTenants: number;
  trialTenants: number;
  suspendedTenants: number;
  totalRouters: number;
  totalVouchers: number;
  totalUsers: number;
}

interface NextUp {
  key: string;
  tone: Tone;
  icon: LucideIcon;
  title: string;
  detail: string;
  flag?: string;
  to: string;
}

const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;

function buildNextUp(s: PlatformStats): NextUp[] {
  const items: NextUp[] = [];
  if (s.totalTenants === 0) {
    items.push({
      key: 'none', tone: 'orange', icon: PlusCircle, to: '/tenants',
      title: 'No ISP accounts yet',
      detail: 'Accounts appear here as providers register.',
    });
  }
  if (s.suspendedTenants > 0) {
    items.push({
      key: 'suspended', tone: 'red', icon: PauseCircle, to: '/tenants', flag: 'Needs attention',
      title: `${plural(s.suspendedTenants, 'ISP account', 'ISP accounts')} suspended`,
      detail: 'Their customers are offline until the account is reactivated.',
    });
  }
  if (s.trialTenants > 0) {
    items.push({
      key: 'trial', tone: 'blue', icon: FlaskConical, to: '/tenants',
      title: `${plural(s.trialTenants, 'ISP', 'ISPs')} on trial`,
      detail: 'Check in before the trial ends so they convert to a paid plan.',
    });
  }
  return items;
}

export function PlatformDashboardPage() {
  const { admin } = usePlatformAuth();
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    platformApi.get('/platform/stats')
      .then((r) => setStats(r.data.data))
      .catch(() => setError('We couldn’t load platform statistics. Check your connection and refresh.'))
      .finally(() => setLoading(false));
  }, []);

  const nextUp = stats ? buildNextUp(stats) : [];
  const urgent = nextUp.filter((n) => n.tone === 'red').length;
  const firstName = admin?.fullName?.split(' ')[0] || 'there';

  return (
    <div className="space-y-6">
      {error && <Notice>{error}</Notice>}

      <section className="panel p-5 sm:p-6">
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
          Platform admin{stats && ` — ${plural(stats.activeTenants, 'ISP', 'ISPs')} active`}
        </p>
        <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-navy-900 dark:text-white">
          {greeting()}, <span className="text-wire-orange-dark dark:text-wire-orange">{firstName}</span>.
        </h1>
        {loading ? (
          <Skeleton className="mt-3 h-5 w-64" />
        ) : stats && (
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
            {urgent > 0
              ? `${plural(urgent, 'thing needs', 'things need')} a minute.`
              : 'Every ISP account is in good standing.'}
          </p>
        )}
        <WireRule className="mt-5 w-20" />
      </section>

      {loading ? (
        <div className="grid gap-4 md:grid-cols-3">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="h-32" />)}
        </div>
      ) : stats && (
        <>
          <div className="grid gap-4 md:grid-cols-3">
            <KpiCard
              label="Active ISPs" tone="green" icon={Activity} to="/tenants"
              value={stats.activeTenants}
              caption={`of ${stats.totalTenants} total accounts`}
            />
            <KpiCard
              label="On trial" tone="blue" icon={FlaskConical} to="/tenants"
              value={stats.trialTenants}
              caption="Not yet on a paid plan"
            />
            <KpiCard
              label="Suspended" tone={stats.suspendedTenants > 0 ? 'brown' : 'slate'} icon={PauseCircle} to="/tenants"
              value={stats.suspendedTenants}
              caption={stats.suspendedTenants > 0 ? 'Offline until reactivated' : 'None right now'}
            />
          </div>

          <Panel className="!p-0">
            <dl className="grid divide-y divide-slate-200/80 dark:divide-white/10 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
              {([
                { label: 'Routers', value: stats.totalRouters, icon: Server, tone: 'blue' },
                { label: 'Vouchers', value: stats.totalVouchers, icon: Ticket, tone: 'orange' },
                { label: 'End users', value: stats.totalUsers, icon: Users, tone: 'green' },
              ] as const).map((cell) => (
                <div key={cell.label} className="flex items-center gap-3 p-4 sm:p-5">
                  <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${TONE[cell.tone].chip}`}>
                    <cell.icon size={17} aria-hidden="true" />
                  </span>
                  <div>
                    <dt className="text-xs text-slate-500 dark:text-slate-400">{cell.label}</dt>
                    <dd className="text-lg font-bold tabular-nums text-navy-900 dark:text-white">{cell.value.toLocaleString()}</dd>
                  </div>
                </div>
              ))}
            </dl>
          </Panel>

          <Panel
            title="What’s next?"
            subtitle={nextUp.length > 0 ? 'Start with the first one.' : undefined}
            action={urgent > 0 ? <span className={`rounded-full px-2.5 py-1 ${TONE.red.chip}`}>{urgent} urgent</span> : undefined}
          >
            {nextUp.length === 0 ? (
              <NextUpItem tone="green" icon={CheckCircle2} title="All clear" detail="No suspended accounts and no trials to chase." />
            ) : (
              <div className="grid gap-2.5 lg:grid-cols-2">
                {nextUp.map(({ key, ...item }) => <NextUpItem key={key} {...item} />)}
              </div>
            )}
          </Panel>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            <Building2 size={12} className="mr-1 inline align-[-2px]" aria-hidden="true" />
            Manage every provider from <Link to="/tenants" className="font-semibold text-wire-blue-dark hover:underline dark:text-wire-blue">ISP accounts</Link>.
          </p>
        </>
      )}
    </div>
  );
}
