import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Wifi, Server, Ticket, Activity, Wallet, Package,
  AlertTriangle, CheckCircle2, PlusCircle, Boxes,
} from 'lucide-react';
import ispApi from '../../services/ispApi';
import { useIspAuth } from '../../contexts/isp/IspAuthContext';
import {
  EmptyState, FeedItem, KpiCard, NextUpItem, Notice, Panel,
  Skeleton, Sparkline, TONE, WireRule, greeting, timeAgo,
} from '../../components/ui/console';
import type { Tone } from '../../components/ui/console';
import type { LucideIcon } from 'lucide-react';

interface RouterSummary {
  id: string;
  name: string;
  host: string;
  status?: string;
  _count?: { hotspotSessions?: number };
}

interface ActivityEntry {
  id: string;
  action: string;
  description?: string;
  createdAt: string;
}

interface TrendPoint {
  hour: string;
  users: number;
  traffic: number;
}

interface DashboardStats {
  plansCount: number;
  activeVouchersCount: number;
  unusedVouchersCount: number;
  onlineUsersCount: number;
  totalIncome: number;
  totalRouters: number;
  onlineRoutersCount: number;
  offlineRoutersCount: number;
  dataUsage?: { formatted: string };
  recentActivity: ActivityEntry[];
  routersSummary: RouterSummary[];
  hourlyTrend?: TrendPoint[];
}

interface NextUp {
  key: string;
  tone: Tone;
  icon: LucideIcon;
  title: string;
  detail: string;
  flag?: string;
  to?: string;
}

const REFRESH_MS = 30_000;

const sentenceCase = (s: string) => {
  const t = s.replace(/_/g, ' ').toLowerCase();
  return t.charAt(0).toUpperCase() + t.slice(1);
};

function buildNextUp(stats: DashboardStats): NextUp[] {
  const items: NextUp[] = [];
  const offline = stats.routersSummary.filter((r) => r.status === 'OFFLINE');

  if (stats.totalRouters === 0) {
    items.push({
      key: 'no-router', tone: 'blue', icon: Server, to: '/routers',
      title: 'Add your first router',
      detail: 'Connect a MikroTik router so customers can get online.',
    });
  }
  if (offline.length > 0) {
    const names = offline.slice(0, 2).map((r) => r.name).join(', ');
    items.push({
      key: 'offline', tone: 'red', icon: AlertTriangle, to: '/routers', flag: 'Needs attention',
      title: `${offline.length} router${offline.length === 1 ? '' : 's'} offline`,
      detail: `We can't reach ${names}${offline.length > 2 ? ' and others' : ''}. Check power and the uplink.`,
    });
  }
  if (stats.plansCount === 0) {
    items.push({
      key: 'no-plan', tone: 'orange', icon: Package, to: '/plans', flag: 'Blocks sales',
      title: 'Create your first plan',
      detail: 'Customers can’t buy access until a plan exists.',
    });
  } else if (stats.unusedVouchersCount === 0) {
    items.push({
      key: 'no-vouchers', tone: 'brown', icon: Boxes, to: '/vouchers', flag: 'Running low',
      title: 'No unused vouchers left',
      detail: 'Generate a batch so you can keep selling.',
    });
  }
  return items;
}

export function IspDashboardPage() {
  const { tenant } = useIspAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(() => {
    ispApi.get('/isp/dashboard/stats')
      .then((r) => { setStats(r.data.data); setError(''); })
      .catch(() => setError('We couldn’t load your dashboard. Check your connection and refresh.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
    const id = window.setInterval(load, REFRESH_MS);
    return () => window.clearInterval(id);
  }, [load]);

  const business = tenant?.businessName || tenant?.name || 'there';
  const nextUp = stats ? buildNextUp(stats) : [];
  const needsAttention = nextUp.filter((n) => n.tone === 'red' || n.tone === 'orange').length;
  const trend = stats?.hourlyTrend ?? [];
  const latest = stats?.recentActivity?.[0];

  return (
    <div className="space-y-6">
      {error && <Notice>{error}</Notice>}

      {/* Greeting + traffic */}
      <section className="panel overflow-hidden">
        <div className="grid gap-6 p-5 sm:p-6 lg:grid-cols-[1.1fr_1fr] lg:gap-10">
          <div>
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
              {tenant?.businessName || tenant?.name || 'Your network'}
              {stats && ` — ${stats.onlineUsersCount} online right now`}
            </p>
            <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-navy-900 dark:text-white">
              {greeting()}, <span className="text-wire-orange-dark dark:text-wire-orange">{business}</span>.
            </h1>
            {loading ? (
              <Skeleton className="mt-3 h-5 w-64" />
            ) : stats && (
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
                {needsAttention > 0
                  ? `${needsAttention} thing${needsAttention === 1 ? '' : 's'} need${needsAttention === 1 ? 's' : ''} a minute.`
                  : 'Everything is running normally.'}
              </p>
            )}
            <WireRule className="mt-5 w-20" />
            {latest && (
              <p className="mt-5 flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
                <span className="rounded-full bg-wire-green/15 px-2 py-0.5 text-xs font-semibold text-wire-green-dark dark:text-wire-green">
                  Latest
                </span>
                <span className="truncate">{sentenceCase(latest.action)}</span>
                <span className="shrink-0 text-xs text-slate-500">{timeAgo(latest.createdAt)}</span>
              </p>
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-sm font-bold text-navy-900 dark:text-white">Traffic over the last day</h2>
              {stats?.dataUsage && (
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">{stats.dataUsage.formatted} used</span>
              )}
            </div>
            {loading ? (
              <Skeleton className="mt-3 h-24 w-full" />
            ) : trend.length > 1 ? (
              <Sparkline
                values={trend.map((p) => p.traffic)}
                tone="blue"
                height={96}
                label="Network traffic in megabytes, sampled every two hours over the last day"
                className="mt-3"
              />
            ) : (
              <p className="mt-4 text-xs text-slate-500 dark:text-slate-400">
                Traffic history appears here once your routers start reporting.
              </p>
            )}
            {stats && (
              <p className="mt-2 text-right text-xs text-slate-500 dark:text-slate-400">
                {stats.onlineRoutersCount}/{stats.totalRouters} routers healthy
              </p>
            )}
          </div>
        </div>
      </section>

      {/* Headline numbers */}
      {loading ? (
        <div className="grid gap-4 md:grid-cols-3">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="h-36" />)}
        </div>
      ) : stats && (
        <>
          <div className="grid gap-4 md:grid-cols-3">
            <KpiCard
              label="Online now" tone="green" icon={Wifi} to="/sessions"
              value={stats.onlineUsersCount}
              caption={`${stats.onlineRoutersCount} of ${stats.totalRouters} routers online`}
              series={trend.map((p) => p.users)}
              seriesLabel="Online users over the last day"
            />
            <KpiCard
              label="Revenue" tone="orange" icon={Wallet}
              value={`₦${stats.totalIncome.toLocaleString()}`}
              caption="From voucher sales"
            />
            <KpiCard
              label="Active vouchers" tone="blue" icon={Ticket} to="/vouchers"
              value={stats.activeVouchersCount}
              caption={`${stats.unusedVouchersCount} unused, ready to sell`}
            />
          </div>

          <Panel className="!p-0">
            <dl className="grid divide-y divide-slate-200/80 dark:divide-white/10 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
              {([
                { label: 'Plans', value: stats.plansCount, to: '/plans', icon: Package, tone: 'brown' },
                { label: 'Routers', value: stats.totalRouters, to: '/routers', icon: Server, tone: 'blue' },
                { label: 'Data used', value: stats.dataUsage?.formatted ?? '—', to: '/sessions', icon: Activity, tone: 'orange' },
              ] as const).map((cell) => (
                <Link key={cell.label} to={cell.to} className="flex items-center gap-3 p-4 transition-colors hover:bg-slate-50/70 dark:hover:bg-white/5 sm:p-5">
                  <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${TONE[cell.tone].chip}`}>
                    <cell.icon size={17} aria-hidden="true" />
                  </span>
                  <div>
                    <dt className="text-xs text-slate-500 dark:text-slate-400">{cell.label}</dt>
                    <dd className="text-lg font-bold tabular-nums text-navy-900 dark:text-white">{cell.value}</dd>
                  </div>
                </Link>
              ))}
            </dl>
          </Panel>

          <div className="grid gap-6 lg:grid-cols-2">
            <Panel
              title="What’s next?"
              subtitle={nextUp.length > 0 ? 'Start with the first one.' : undefined}
              action={needsAttention > 0 ? <span className={`rounded-full px-2.5 py-1 ${TONE.red.chip}`}>{needsAttention} urgent</span> : undefined}
            >
              {nextUp.length === 0 ? (
                <NextUpItem
                  tone="green" icon={CheckCircle2}
                  title="All clear"
                  detail="Routers are online and vouchers are in stock."
                />
              ) : (
                <div className="space-y-2.5">
                  {nextUp.map(({ key, ...item }) => <NextUpItem key={key} {...item} />)}
                </div>
              )}
            </Panel>

            <Panel title="Latest activity" subtitle="The most recent changes on your account.">
              {stats.recentActivity.length === 0 ? (
                <EmptyState
                  icon={Activity}
                  title="Nothing yet"
                  body="Sales, sign-ins and router changes will show up here."
                />
              ) : (
                <ul className="divide-y divide-slate-200/70 dark:divide-white/10">
                  {stats.recentActivity.map((log) => (
                    <FeedItem
                      key={log.id}
                      tone="blue"
                      icon={Activity}
                      title={sentenceCase(log.action)}
                      detail={log.description}
                      time={timeAgo(log.createdAt)}
                    />
                  ))}
                </ul>
              )}
            </Panel>
          </div>

          <Panel
            title="Routers"
            action={<Link to="/routers" className="text-wire-blue-dark hover:underline dark:text-wire-blue">Manage routers</Link>}
          >
            {stats.routersSummary.length === 0 ? (
              <EmptyState
                icon={Server}
                title="No routers connected"
                body="Add a router to start selling access and see live sessions."
                action={<Link to="/routers" className="btn-primary"><PlusCircle size={16} aria-hidden="true" />Add a router</Link>}
              />
            ) : (
              <ul className="divide-y divide-slate-200/70 dark:divide-white/10">
                {stats.routersSummary.map((router) => {
                  const online = router.status === 'ONLINE';
                  const offline = router.status === 'OFFLINE';
                  return (
                    <li key={router.id} className="flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-navy-900 dark:text-white">{router.name}</p>
                        <p className="truncate text-xs text-slate-500 dark:text-slate-400">{router.host}</p>
                      </div>
                      <div className="flex shrink-0 items-center gap-3">
                        <span className="text-xs text-slate-500 dark:text-slate-400">{router._count?.hotspotSessions ?? 0} online</span>
                        <span className={online ? 'pill-green' : offline ? 'pill-red' : 'pill-brown'}>
                          <span className={`h-1.5 w-1.5 rounded-full ${online ? TONE.green.dot : offline ? TONE.red.dot : TONE.brown.dot}`} aria-hidden="true" />
                          {online ? 'Online' : offline ? 'Offline' : 'Unknown'}
                        </span>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </Panel>
        </>
      )}
    </div>
  );
}
